mv shellium.py /usr/local/bin/shellium
echo "Successfully installed in /usr/local/bin"
