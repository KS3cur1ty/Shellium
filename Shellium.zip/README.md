# Shellium
Shellium is an Interactive Reverse Shell generator.
- [Features](#Features)
- [Installation](#Installation)
  - [On Linux/MacOS](#On-Linux/MacOS)
  - [On Windows](#On-Windows)
- [Usage](#Usage)
- [Author](#Author)
- [License](#License)

# Features

- Supports IPv4 and IPv6
- IPv4 and IPv6 format validation
- Port number validation
- Colored text
- Supported Reverse Shells : Bash, Python2 & Python3, PHP, Perl, Java, Netcat, and Ruby

# Installation
## On Linux/MacOS
### Clone the Repository
```git
git clone https://github.com/K-S3curity/Shellium.git
```
### Go into the cloned Repository
```bash
cd Shellium
```
### Give the installer script execution permissions and execute it
```bash
chmod +x install.sh && ./install.sh
```
## On Windows
### Clone the Repository
```git
git clone https://github.com/K-S3curity/Shellium.git
```
### Navigate into the directory 
### Execute *`shellium.py`* manually or in the command line with :
```
python3 shellium.py
```
# Usage
## On Linux/MacOS
Just type this command in your terminal emulator, no matter from which directory you've executed it.
```bash
shellium
```
## On Windows
Execute *`shellium.py`*
# Author
**K-S3curity**
- [Github](https://github.com/K-S3curity)
- [Twitter](https://twitter.com/KS3curity)

Give a star to support my work !

# License
[GNU GPLv3](https://www.gnu.org/licenses/gpl-3.0.en.html)